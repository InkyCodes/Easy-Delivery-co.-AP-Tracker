require("scripts.autotracking.item_mapping")
require("scripts.autotracking.location_mapping")

CUR_INDEX = -1
--SLOT_DATA = nil

ALL_LOCATIONS = {}
SLOT_DATA = {}

MANUAL_CHECKED = true
ROOM_SEED = "default"
TROLL_PLAYER = false

if Highlight then
    HIGHLIGHT_LEVEL= {
        [0] = Highlight.Unspecified,
        [10] = Highlight.NoPriority,
        [20] = Highlight.Avoid,
        [30] = Highlight.Priority,
        [40] = Highlight.None,
        [100] = Highlight.Unspecified, --Filler
        [101] = Highlight.Priority, --Progression
        [102] = Highlight.NoPriority, --Useful
        [103] = Highlight.Priority, -- Prog + Useful
        [104] = Highlight.Avoid, --Trap
        [105] = Highlight.Priority, -- Prog + Trap
        [106] = Highlight.NoPriority, -- Useful + Trap
        [107] = Highlight.Priority, -- Prog + Useful + Trap
    }
end

Troll_Lookup = {
    ["solarcell"] = true,
    ["earthor"] = true,
}

---function to build a pretty-printable representation of a provided table
---@param o table
---@param depth? integer
---@return string
function DumpTable(o, depth)
    if depth == nil then
        depth = 0
    end
    if type(o) == 'table' then
        local tabs = ('\t'):rep(depth)
        local tabs2 = ('\t'):rep(depth + 1)
        local s = '{\n'
        for k, v in pairs(o) do
            if type(k) ~= 'number' then
                k = '"' .. k .. '"'
            end
            s = s .. tabs2 .. '[' .. k .. '] = ' .. DumpTable(v, depth + 1) .. ',\n'
        end
        return s .. tabs .. '}'
    else
        return tostring(o)
    end
end

---helper function that gets called when a LocationSection has changed state.
---checks if the interaction was from the server or manual.
---if manual, puts it into a cache for keeping that LocationSection toggled when reconnecting
---@param location LocationSection
function LocationHandler(location)
    if MANUAL_CHECKED then
        local custom_storage_item = Tracker:FindObjectForCode("manual_location_storage").ItemState
        if not custom_storage_item then
            return
        end
        if Archipelago.PlayerNumber == -1 then -- not connected
            if ROOM_SEED ~= "default" then -- seed is from previous connection
                ROOM_SEED = "default"
                custom_storage_item.MANUAL_LOCATIONS["default"] = {}
            else -- seed is default
            end
        end
        local full_path = location.FullID
        if not custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED] then
            custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED] = {}
        end
        if location.AvailableChestCount < location.ChestCount then --add to list
            -- print("add to list")
            custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED][full_path] = location.AvailableChestCount
        else --remove from list of set back to max chestcount
            -- print("remove from list")
            custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED][full_path] = nil
        end
    end
    -- local custom_storage_item = Tracker:FindObjectForCode("manual_location_storage").ItemState
    -- print(DumpTable(storage_item.ItemState.MANUAL_LOCATIONS))
    ForceUpdate() --
end

--function to force an update even if the interaction within poptracker noramlly would not call for a state update
function ForceUpdate()
    local update = Tracker:FindObjectForCode("update")
    if update == nil then
        return
    end
    update.Active = not update.Active
end


---resets or updates a given item back to default or what's saved for the given seed in the pseudo-cache LuaItems
---@param item_code JsonItem|string Tracker:FindObjectForCode(item) return object
---@param item_type string|nil table of the ItemCode and extra parameters from the Item_Mapping.lau
---@param consumable_multiplier integer|nil table of the ItemCode and extra parameters from the Item_Mapping.lua
---@param reset boolean|nil flag to update or reset the item false=update, true=reset, nil=update
local function ItemUpdate(item_code, item_type, consumable_multiplier, reset)
    local item_obj = nil

    if type(item_code) == "string" then
        item_obj = Tracker:FindObjectForCode(item_code)
    else
        item_obj = item_code
    end
    if item_obj == nil then
        print(string.format("ItemUpdate: could not find item_object for code %s", item_code))
        return
    end

    if item_type == nil then
        item_type = item_obj.Type
    end

    if item_type == "toggle" then
        item_obj.Active = not reset --reset and false or true
    elseif item_type == "progressive" then
        item_obj.CurrentStage = reset and 0 or (item_obj.CurrentStage + 1)
    elseif item_type == "consumable" then
        item_obj.AcquiredCount = reset and (item_obj.MinCount or 0) or
        (item_obj.AcquiredCount + item_obj.Increment * (consumable_multiplier or 1))
    elseif item_type == "progressive_toggle" then
        item_obj.CurrentStage = reset and 0 or (item_obj.CurrentStage + 1)
        item_obj.Active = not reset -- reset and false or true
    end
end


---resets or updates a given location back to default or whats saved for the gives seed in the pseudo-cache LuaItems
---@param location_obj LocationSection Tracker:FindObjectForCode(location) return object
---@param custom_storage_item table Reference for the custom LuaItem CachesItems
---@param reset boolean flag to update or reset the item false=update, true=reset, nil=update
local function LocationUpdate(location_obj, custom_storage_item, reset)
    ---@cast location_obj LocationSection
    if reset then --reset
        if custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED][location_obj.FullID] then
            location_obj.AvailableChestCount = custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED][location_obj.FullID]
        else
            location_obj.AvailableChestCount = location_obj.ChestCount
        end
        location_obj.Highlight = HIGHLIGHT_LEVEL[40]
    else --update
        (location_obj --[[@as LocationSection]]).AvailableChestCount = location_obj.AvailableChestCount - 1
    end
end


--- Function to prepare custom LuaItems for caching, check for mischieve/traps, subscribe to datastorage
local function PreOnClear()
    PLAYER_ID = Archipelago.PlayerNumber or -1
	TEAM_NUMBER = Archipelago.TeamNumber or 0
    if PLAYER_ID > -1 then
        for key, _ in pairs(Troll_Lookup) do
            if string.find(string.lower(Archipelago:GetPlayerAlias(PLAYER_ID)), key, 1, true) ~= nil then
                TROLL_PLAYER = true
                break
            end
        end

        --- example for how to build a date object and how to check current user's date against it
        --local start_day_range = BuildTimeObj(nil, 3 , 31)
        --local end_day_range = BuildTimeObj(nil, 4 , 5)
        --DATE_CHECK_PASSED = CheckDateRange(start_day_range, end_day_range, os.time())
        --if TROLL_PLAYER == false and DATE_CHECK_PASSED then
        --    TROLL_PLAYER = true
        --end

        if #ALL_LOCATIONS > 0 then
            ALL_LOCATIONS = {}
        end
        for _, value in pairs(Archipelago.MissingLocations) do
            table.insert(ALL_LOCATIONS, #ALL_LOCATIONS + 1, value)
        end

        for _, value in pairs(Archipelago.CheckedLocations) do
            table.insert(ALL_LOCATIONS, #ALL_LOCATIONS + 1, value)
        end
        ---add more of those for other datastorage keys
        HINTS_ID = "_read_hints_"..TEAM_NUMBER.."_"..PLAYER_ID
        Archipelago:SetNotify({HINTS_ID}) --{HINTS_ID, other vars, ...}
        Archipelago:Get({HINTS_ID}) --{HINTS_ID, other vars, ...}
    end


    -- print(Archipelago.Seed)
    local seed_base = (Archipelago.Seed or tostring(#ALL_LOCATIONS)).."_"..Archipelago.TeamNumber.."_"..Archipelago.PlayerNumber
    if ROOM_SEED == "default" or ROOM_SEED ~= seed_base then -- seed is default or from previous connection

        ROOM_SEED = seed_base --something like 2345_0_12
        for _, custom_item_code in pairs({"manual_location_storage"}) do -- add more to the table if you created more storage cache items
            local custom_storage_item = Tracker:FindObjectForCode(custom_item_code).ItemState
            if custom_storage_item then
                if #custom_storage_item.MANUAL_LOCATIONS > 10 then
                    custom_storage_item.MANUAL_LOCATIONS[custom_storage_item.MANUAL_LOCATIONS_ORDER[1]] = nil
                    table.remove(custom_storage_item.MANUAL_LOCATIONS_ORDER, 1)
                end
                if custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED] == nil then
                    custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED] = {}
                    table.insert(custom_storage_item.MANUAL_LOCATIONS_ORDER, ROOM_SEED)
                end
            end
        end
    else -- seed is from previous connection
        -- do nothing
    end
end

-- ============================================================
-- RESET FÜR NEUEN RUN
-- Blind Bags + Snowcats + Radio Towers
-- ============================================================

local function ResetSpecialRunState(custom_storage_item)

    local special_location_ids = {
        -- Blind Bags
        20, 21, 22, 23,
        24, 25, 26, 27,
        28, 29, 30, 31,

        -- Snowcats
        40, 41, 42, 43, 44, 45, 46,
        47, 48, 49, 50, 51, 52,

        -- Radio Towers
        60, 61, 62, 63
    }

    for _, location_id in ipairs(special_location_ids) do
        local location_array = LOCATION_MAPPING[location_id]

        if location_array then
            for _, entry in ipairs(location_array) do

                -- LocationSection zurücksetzen
                if type(entry) == "string" and entry:sub(1, 1) == "@" then
                    local location_obj = Tracker:FindObjectForCode(entry)

                    if location_obj
                        and location_obj.ChestCount ~= nil
                        and location_obj.AvailableChestCount ~= nil
                    then
                        location_obj.AvailableChestCount = location_obj.ChestCount

                        if HIGHLIGHT_LEVEL and HIGHLIGHT_LEVEL[40] then
                            location_obj.Highlight = HIGHLIGHT_LEVEL[40]
                        end

                        if custom_storage_item
                            and custom_storage_item.MANUAL_LOCATIONS
                            and custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED]
                        then
                            custom_storage_item.MANUAL_LOCATIONS[ROOM_SEED][location_obj.FullID] = nil
                        end
                    end

                -- Zusätzliche Items aus LOCATION_MAPPING zurücksetzen,
                -- z. B. radiotower_upton
                elseif type(entry) == "table" then
                    local item_code, item_type, consumable_multiplier = table.unpack(entry)
                    ItemUpdate(
                        item_code,
                        item_type,
                        consumable_multiplier,
                        true
                    )
                end
            end
        end
    end

    -- Sicherheitshalber die vier individuellen Tower-Icons resetten
    local tower_icons = {
        "radiotower_upton",
        "radiotower_easton",
        "radiotower_snowypeaks",
        "radiotower_fishingtown"
    }

    for _, code in ipairs(tower_icons) do
        local item = Tracker:FindObjectForCode(code)
        if item then
            item.Active = false
        end
    end
end


---function that gets called when the pack connects to an AP server
---@param slot_data? table Slotdata send from AP server for the specific user/slot
function OnClear(slot_data)

    print("SLOT DATA:")
    print(DumpTable(slot_data))

    MANUAL_CHECKED = false

    local previous_room_seed = ROOM_SEED

    local custom_storage_object =
        Tracker:FindObjectForCode("manual_location_storage")

    local custom_storage_item = nil

    if custom_storage_object then
        custom_storage_item =
            custom_storage_object.ItemState
    end

    if custom_storage_item == nil then
        CreateLuaManualStorageItem(
            "manual_location_storage"
        )

        custom_storage_item =
            Tracker:FindObjectForCode(
                "manual_location_storage"
            ).ItemState
    end

    PreOnClear()

    -- Prüfen, ob wir wirklich in einem neuen Run sind
    local is_new_run =
        previous_room_seed ~= ROOM_SEED

    print(
        "ROOM SEED:",
        previous_room_seed,
        "->",
        ROOM_SEED,
        "NEW RUN:",
        is_new_run
    )

    ScriptHost:RemoveWatchForCode("StateChanged")
    ScriptHost:RemoveOnLocationSectionHandler("location_section_change_handler")

    CUR_INDEX = -1

    for _, location_array in pairs(LOCATION_MAPPING) do
        for _, location in pairs(location_array) do
            if location then
                if type(location) == "table" then
                    item_code, item_type, consumable_multiplies = table.unpack(location)
                    ItemUpdate(item_code, item_type, consumable_multiplies, true)
                else
                    if location:sub(1, 1) == "@" then
                        local location_obj = Tracker:FindObjectForCode(location)

                        if location_obj then
                            LocationUpdate(location_obj, custom_storage_item, true)
                        end
                    else
                        ItemUpdate(location_obj, nil, nil, true)
                    end
                end
            end
        end
    end
    -- reset items
    for _, item_array in pairs(ITEM_MAPPING) do
        for _, item_pair in pairs(item_array) do
            local item_code = item_pair[1]
            local item_type = item_pair[2]
            local consumable_multiplier = tonumber(item_pair[3]) or 1
            -- print("on clear", item_code, item_type)
			---@type JsonItem
            local item_obj = Tracker:FindObjectForCode(item_code)
            if item_obj then
                ItemUpdate(item_obj, item_type, consumable_multiplier, true)
            end
        end
    end
-- ============================================================
-- NEUER RUN -> CUSTOM LOCATIONS/ICONS KOMPLETT RESETTEN
-- ============================================================

if is_new_run then

    print(
        "NEW RUN DETECTED - RESETTING BLIND BAGS, SNOWCATS AND RADIO TOWERS"
    )

    ResetSpecialRunState(
        custom_storage_item
    )
end
    PLAYER_ID = Archipelago.PlayerNumber or -1
    TEAM_NUMBER = Archipelago.TeamNumber or 0
    SLOT_DATA = slot_data
    -- if Tracker:FindObjectForCode("autofill_settings").Active == true then
    --     AutoFill(slot_data)
    -- end
    -- print(PLAYER_ID, TEAM_NUMBER)
    if Archipelago.PlayerNumber > -1 then
        if #ALL_LOCATIONS > 0 then
            ALL_LOCATIONS = {}
        end
        for _, value in pairs(Archipelago.MissingLocations) do
            table.insert(ALL_LOCATIONS, #ALL_LOCATIONS + 1, value)
        end

        for _, value in pairs(Archipelago.CheckedLocations) do
            table.insert(ALL_LOCATIONS, #ALL_LOCATIONS + 1, value)
        end

        HINTS_ID = "_read_hints_"..TEAM_NUMBER.."_"..PLAYER_ID
        Archipelago:SetNotify({HINTS_ID})
        Archipelago:Get({HINTS_ID})
    end
    ScriptHost:AddOnFrameHandler("load handler", OnFrameHandler)
    MANUAL_CHECKED = true
end

---Run every time an Item gets sent to the connected slot
---@param index integer running index for the items the connected slot has received so far
---@param item_id integer ID of the received item, matching the game's datapackage ID
---@param item_name string name of the item from the datapackage for the given itemID
---@param player_number integer slotnumber of the player who picked up the item
function OnItem(index, item_id, item_name, player_number)

    print("AP ITEM:", item_id, item_name, player_number)

    if index <= CUR_INDEX then
        return
    end

    local is_local = player_number == Archipelago.PlayerNumber

    CUR_INDEX = index

    local item = ITEM_MAPPING[item_id]

    if not item or not item[1] then
        print(
            string.format(
                "OnItem: could not find item mapping for id %s (%s)",
                tostring(item_id),
                tostring(item_name)
            )
        )
        return
    end

    print("FOUND ITEM MAPPING FOR:", item_id)

    for _, item_pair in pairs(item) do
        local item_code = item_pair[1]
        local item_type = item_pair[2]
        local consumable_multiplier = tonumber(item_pair[3]) or 1

        print(
            "UPDATING ITEM:",
            item_code,
            item_type
        )

        local item_obj = Tracker:FindObjectForCode(item_code)

        if item_obj then
            ItemUpdate(
                item_code,
                item_type,
                consumable_multiplier,
                false
            )
        else
            print(
                string.format(
                    "OnItem: could not find object for code %s",
                    item_code
                )
            )
        end
    end
end

---called when a location gets cleared
---@param location_id integer ID of the location cleared from the datapackage
---@param location_name string name of the location cleared from the datapackage
function OnLocation(location_id, location_name)

    print("AP LOCATION:", location_id, location_name)

    MANUAL_CHECKED = false

    local location_array = LOCATION_MAPPING[location_id]

    if not location_array or not location_array[1] then
        print(string.format(
            "OnLocation: could not find location mapping for id %s (%s)",
            tostring(location_id),
            tostring(location_name)
        ))

        MANUAL_CHECKED = true
        return
    end

    print("FOUND LOCATION MAPPING FOR:", location_id)

    for _, location in pairs(location_array) do
        if location then

            if type(location) == "table" then

                local item_code, item_type, consumable_multiplier =
                    table.unpack(location)

                print(
                    "UPDATING ITEM FROM LOCATION:",
                    item_code,
                    item_type
                )

                ItemUpdate(
                    item_code,
                    item_type,
                    consumable_multiplier,
                    false
                )

            else

                print(
                    "UPDATING LOCATION OBJECT:",
                    location
                )

                if location:sub(1, 1) == "@" then

                    ---@type LocationSection
                    local location_obj =
                        Tracker:FindObjectForCode(location)

                    if location_obj then

                        print(
                            "FOUND TRACKER LOCATION:",
                            location
                        )

                        LocationUpdate(
                            location_obj,
                            custom_storage_item,
                            false
                        )

                    else

                        print(
                            string.format(
                                "OnLocation: could not find location_object for code %s",
                                location
                            )
                        )

                    end

                else

                    ---@cast location_obj JsonItem
                    ItemUpdate(
                        location,
                        nil,
                        nil,
                        false
                    )

                end
            end
        end
    end

    MANUAL_CHECKED = true
end

-- this Autofill function is meant as an example on how to do the reading from slot_data
-- and mapping the values to your own settings
-- ---@param slot_data table
-- function AutoFill(slot_data)
--     -- print(DumpTable(slot_data))

--     mapToggle={[0]=0,[1]=1,[2]=1,[3]=1,[4]=1}
--     mapToggleReverse={[0]=1,[1]=0,[2]=0,[3]=0,[4]=0}
--     mapTripleReverse={[0]=2,[1]=1,[2]=0}

--     slotCodes = {
--         map_name = {code="", mapping=mapToggle...}
--     }
--     -- print(Tracker:FindObjectForCode("autofill_settings").Active)
--     if Tracker:FindObjectForCode("autofill_settings").Active == true then
--         for settings_name, settings_value in pairs(slot_data) do
--             -- print(k, v)
--             if slotCodes[settings_name] then
--                 item = Tracker:FindObjectForCode(slotCodes[settings_name].code)
--                 if item.Type == "toggle" then
--                     item.Active = slotCodes[settings_name].mapping[settings_value]
--                 else
--                     -- print(k,v,Tracker:FindObjectForCode(slotCodes[k].code).CurrentStage, slotCodes[k].mapping[v])
--                     item.CurrentStage = slotCodes[settings_name].mapping[settings_value]
--                 end
--             end
--         end
--     end
-- end

---@class APHintMessage
---@field receiving_player integer
---@field finding_player integer
---@field location integer
---@field item integer
---@field found boolean
---@field entrance string
---@field item_flags 0|1|2|3|4|5|6|7
---@field status 0|10|20|30|40

---function to update the Highlight of a LocationSection to represent the status of the hint that is present
---for that LocationSection
---@param locationID integer ID of the locations the hint is being given for
---@param status 0|10|20|30|40|100|101|102|103|104|105|106|107 status to determine the color of the hint glow
local function UpdateHints(locationID, status) -->
    if Highlight then
        -- print(locationID, status)
        local location_table = LOCATION_MAPPING[locationID]
        if not location_table then
            return
        end

        for _, location in ipairs(location_table) do
            if type(location) == "string" and location:sub(1, 1) == "@" then
				---@type LocationSection
                local obj = Tracker:FindObjectForCode(location)

                if obj then
                    if TROLL_PLAYER and HIGHLIGHT_LEVEL[status] == Highlight.Avoid then
                        obj.Highlight = HIGHLIGHT_LEVEL[30]
                    else
                        obj.Highlight = HIGHLIGHT_LEVEL[status]
                    end
                else
                    print(string.format("No object found for code: %s", location))
                end
            end
        end
    end
end

---triggers as AP sends live updates from the server using a given key we subscribed to in Archipelago:SetNotify
---@param key string Name of the key that was used to send the message
---@param value table<integer, APHintMessage>
---@param old_value table<integer, APHintMessage>
function OnNotify(key, value, old_value)
    print("OnNotify", key, value, old_value)
    if value ~= old_value and key == HINTS_ID then
        Tracker.BulkUpdate = true
        for _, hint in ipairs(value) do
            if hint.finding_player == Archipelago.PlayerNumber then
                if hint.status == 0 then
                    UpdateHints(hint.location, 100+hint.item_flags)
                else
                    UpdateHints(hint.location, hint.status)
                end
            end
        end
        Tracker.BulkUpdate = false
    end
end

---triggers on connecting to AP when we receive this message from the server after providing a given key to Archipelago:Get
---@param key string Name of the key that was used to send the message
---@param value table<integer, APHintMessage>
function OnNotifyLaunch(key, value)
    if key == HINTS_ID then
        Tracker.BulkUpdate = true
        for _, hint in ipairs(value) do
            if hint.finding_player == Archipelago.PlayerNumber then
                if hint.status == 0 then
                    UpdateHints(hint.location, 100+hint.item_flags)
                else
                    UpdateHints(hint.location, hint.status)
                end
            end
        end
        Tracker.BulkUpdate = false
    end
end

-------------------
---this section is only for special things that are time of day or day of year dependant if you really want to do stuff
---stuff like this

---@param start_date number BuildTimeObj() return aka unix timestamp
---@param end_date number BuildTimeObj() return aka unix timestamp
---@param target_date number BuildTimeObj() return aka unix timestamp
function CheckDateRange(start_date, end_date, target_date)
    local one_day = 86400
    local check_result = false
    for day_obj = start_date, end_date, one_day do
        check_result = CheckDate(day_obj, target_date)
        if check_result then
            return true
        end
    end
end

---@param target_date number BuildTimeObj() return aka unix timestamp
---@param reference_time number? BuildTimeObj() return aka unix timestamp
function CheckDate(reference_time, target_date)
    local today = os.date("*t")
    local reference_day =  os.date("*t", target_date)
    if reference_time then
        today = os.date("*t", reference_time)
    end
    return today.year == reference_day.year and
    today.month == reference_day.month and
    today.day == reference_day.day
end

---helper function to return a date object for the provided day
---@param year number?
---@param month number?
---@param day number?
---@param hour number?
---@param minute number?
---@param second number?
---@return integer
function BuildTimeObj(year, month, day, hour, minute, second)
    local today = os.date("*t", os.time())
    return os.time(
        {
            year = year or today.year,
            month = month or today.month,
            day = day or today.day,
            hour = hour or 0,
            min = minute or 0,
            sec = second or 0
        }
    )
end
-------------------


--doc
--hint layout
-- {
--     ["receiving_player"] = 1,
--     ["class"] = Hint,
--     ["finding_player"] = 1,
--     ["location"] = 67361,
--     ["found"] = false,
--     ["item_flags"] = 2, --bitflag --> 0=filler, 1=progression, 2=useful, 4=trap
--     ["status"] = 40, --bitflag --> 0=Unspecified, 10=NoPriority, 20=Avoid, 30=Priority, 40=None
--     ["entrance"] = ,
--     ["item"] = 66062,
-- }


----------
---remnant from when poptracker had issues loading some larger/heavy packs
--function OnClearHandler(slot_data)
--    local clear_timer = os.clock()
--
--    ScriptHost:RemoveWatchForCode("StateChange")
--    -- Disable tracker updates.
--    Tracker.BulkUpdate = true
--    -- Use a protected call so that tracker updates always get enabled again, even if an error occurred.
--    local ok, err = pcall(OnClear, slot_data)
--    -- Enable tracker updates again.
--    if ok then
--        -- Defer re-enabling tracker updates until the next frame, which doesn't happen until all received items/cleared
--        -- locations from AP have been processed.
--        local handlerName = "AP OnClearHandler"
--        local function frameCallback()
--            ScriptHost:AddWatchForCode("StateChange", "*", StateChanged)
--            ScriptHost:RemoveOnFrameHandler(handlerName)
--            Tracker.BulkUpdate = false
--            ForceUpdate()
--            print(string.format("Time taken total: %.2f", os.clock() - clear_timer))
--        end
--        ScriptHost:AddOnFrameHandler(handlerName, frameCallback)
--    else
--        Tracker.BulkUpdate = false
--        print("Error: OnClear failed:")
--        print(err)
--    end
--end